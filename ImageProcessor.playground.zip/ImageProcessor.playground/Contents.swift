//: Playground - noun: a place where people can play


import UIKit

let image = UIImage(named: "sample")!
let myRGBA = RGBAImage(image: image )!

class filters {
    var myRGBA: RGBAImage
    
    init(name: String) {
        let image = UIImage(named: name)!
        self.myRGBA = RGBAImage(image: image)!
    }
    
    func applySomeFilters(filterList:Array<String>) -> RGBAImage {
        let copyImage:RGBAImage = self.myRGBA
        for filter in filterList {
            
            switch(filter) {
            case "IncreaseTransparency %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.alpha = UInt8(Int(pixel.alpha) / 2)
                        copyImage.pixels[index] = pixel
                    }
                }
            case "IncreaseRed %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.red = UInt8(max(0, min(255, Int(pixel.red) * 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "IncreaseBlue %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.blue = UInt8(max(0, min(255, Int(pixel.blue) * 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "IncreaseGreen %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.green = UInt8(max(0, min(255, Int(pixel.green) * 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "DecreaseRed %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.red = UInt8(max(0, min(255, Int(pixel.red) / 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "DecreaseBlue %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.blue = UInt8(max(0, min(255, Int(pixel.blue) / 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "DecreaseGreen %100":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        pixel.green = UInt8(max(0, min(255, Int(pixel.green) / 2)))
                        copyImage.pixels[index] = pixel
                    }
                }
            case "Greyscale":
                for y in 0..<copyImage.width {
                    for x in 0..<copyImage.height {
                        let index = y * copyImage.width + x
                        var pixel = copyImage.pixels[index]
                        let red = Int(pixel.red)
                        let green = Int(pixel.green)
                        let blue = Int(pixel.blue)
                        
                        let greyscale = (red + green + blue) / 3
                        
                        pixel.red = UInt8(greyscale)
                        pixel.blue = UInt8(greyscale)
                        pixel.green = UInt8(greyscale)
                        
                        copyImage.pixels[index] = pixel
                    }
                }
                
            default:
                return self.myRGBA
            }
        }
        return copyImage
    }
}

var myImageProcessor = filters(name: "sample")
myImageProcessor.myRGBA.toUIImage()

myImageProcessor.applySomeFilters(["IncreaseTransparency %100", "IncreaseRed %100"]).toUIImage()

myImageProcessor.applySomeFilters(["IncreaseBlue %100"]).toUIImage()

myImageProcessor.applySomeFilters(["IncreaseGreen %100"]).toUIImage()

myImageProcessor.applySomeFilters(["DecreaseRed %100"]).toUIImage()

myImageProcessor.applySomeFilters(["DecreaseGreen %100"]).toUIImage()

myImageProcessor.applySomeFilters(["DecreaseBlue %100"]).toUIImage()

myImageProcessor.applySomeFilters(["Greyscale"]).toUIImage()



