//
//  ViewController.swift
//  DZCalc
//
//  Created by Balaji Lakshmi Ramakrishnan on 4/26/16.
//  Copyright © 2016 Dazel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var final:Float = 0
    var number:String = ""
    var firstNumber:Float = 0
    var secondNumber:Float = 0
    var operation:String = ""
    var numbers:Array<Float> = []
    var operators:Array<String> = []
    
    @IBOutlet weak var display: UILabel!
    
    
    @IBAction func one(sender: UIButton) {
        number+="1"
        display.text = number
    }
    
    
    @IBAction func two(sender: UIButton) {
        number+="2"
        display.text = number
    }
    
    @IBAction func three(sender: UIButton) {
        number+="3"
        display.text = number
    }
    
    @IBAction func four(sender: UIButton) {
        number+="4"
        display.text = number
    }
    
    
    @IBAction func five(sender: UIButton) {
        number+="5"
        display.text = number
    }
    
    @IBAction func six(sender: UIButton) {
        number+="6"
        display.text = number
    }
    
    @IBAction func seven(sender: UIButton) {
        number+="7"
        display.text = number
    }
    
    @IBAction func eight(sender: UIButton) {
        number+="8"
        display.text = number
        
    }
    
    @IBAction func nine(sender: UIButton) {
        number+="9"
        display.text = number
    }
    
    @IBAction func zero(sender: UIButton) {
        number+="0"
        display.text = number
    }
    
    @IBAction func clear(sender: UIButton) {
        number=""
        display.text = number
    }
    
    @IBAction func equal(sender: UIButton) {
        firstNumber = Float(number)!
        numbers.append(firstNumber)
        var finalVal = numbers[0]
        print (numbers)
        print (operators)
        for pos in 0..<operators.count {
            switch operators[pos] {
            case "+":
                finalVal+=numbers[pos+1]
            case "-":
                finalVal-=numbers[pos+1]
            case "*":
                finalVal*=numbers[pos+1]
            case "/":
                finalVal/=numbers[pos+1]
            default:
                finalVal+=0
            }
            
            
        }
        display.text = String(finalVal)
        numbers = []
        operators = []
    }
    
    @IBAction func add(sender: UIButton) {
        
        //secondNumber = Float(number)!
        //firstNumber+=secondNumber
        //number=""
        //display.text = "+"
        firstNumber = Float(number)!
        numbers.append(firstNumber)
        operators.append("+")
        display.text = "+"
        number = ""
    }
    
    @IBAction func subtract(sender: UIButton) {
        firstNumber = Float(number)!
        numbers.append(firstNumber)
        operators.append("-")
        display.text = "-"
        number = ""
    }
    
    @IBAction func multiply(sender: UIButton) {
        firstNumber = Float(number)!
        numbers.append(firstNumber)
        operators.append("*")
        display.text = "*"
        number = ""
    }
    
    @IBAction func divide(sender: UIButton) {
        firstNumber = Float(number)!
        numbers.append(firstNumber)
        operators.append("/")
        display.text = "/"
        number = ""
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

