/** Automatically generated file. DO NOT MODIFY */
package com.example.mycontactlist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}